import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
    private ArrayList<LineSegment> lineSegments;

    private boolean hasNullPoint(Point[] points)
    {
        for (Point p: points) if(p == null) return true;
        return false;
    }

    private static LineSegment[] getArray(ArrayList<LineSegment> ls)
    {
        LineSegment[] lsArray = new LineSegment[ls.size()];
        int i = 0;
        for (LineSegment l : ls) lsArray[i++] = l;
        return lsArray;
    }

    public BruteCollinearPoints(Point[] points)
    {
        if(points == null || hasNullPoint(points)) throw new IllegalArgumentException();
        double slopeValue;
        lineSegments = new ArrayList<>();
        Arrays.sort(points);
        for(int i = 0; i < points.length; i++){
            for (int j = i+1; j < points.length; j++)
            {
                slopeValue = points[i].slopeTo(points[j]);
                if(points[j].compareTo(points[i]) == 0) throw new IllegalArgumentException();
                for (int k = j+1; k < points.length; k++){
                    if(slopeValue == points[i].slopeTo(points[k])){
                        for (int l = k+1; l < points.length; l++){
                            if(slopeValue == points[i].slopeTo(points[l])) {
                                if(points[i] == null || points[j] == null || points[k] == null || points[l] == null)
                                    throw new IllegalArgumentException();
                                lineSegments.add(new LineSegment(points[i], points[l]));
                            }
                        }
                    }
                }
            }
        }
    }
    public int numberOfSegments()
    {
        return lineSegments.size();
    }
    public LineSegment[] segments()
    {
        return getArray(lineSegments);
    }
}
